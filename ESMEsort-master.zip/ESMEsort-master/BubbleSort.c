//
// Created by Medeville Louis on 05/10/2021.
//
#include "BubbleSort.h"

void bubbleSort(int *tabletoSort, int size){
    int x=1;
    int bouboule = 0;
    while(x<size) {
        for (int i = 0; i < size-x; i++) {
            if (*(tabletoSort + i) < *(tabletoSort + i + 1)) {
                int temp = *(tabletoSort + i);
                *(tabletoSort + i) = *(tabletoSort + i + 1);
                *(tabletoSort + i + 1) = temp;
                bouboule = 1;
            }
        }
        if (!bouboule){
            break;
        }
        x++;

    }
}
