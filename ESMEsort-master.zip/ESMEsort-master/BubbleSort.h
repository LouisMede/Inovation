//
// Created by Medeville Louis on 05/10/2021.
//

#ifndef SORT_BUBBLESORT_H
#define SORT_BUBBLESORT_H
#include <stdio.h>

void bubbleSort(int *tabletoSort, int size);

#endif //SORT_BUBBLESORT_H
