#ifndef SORT_MANAGEINTTABLE_H
#define SORT_MANAGEINTTABLE_H
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void fillTableWithRandomInt(int *tableToFill, int size);
void showConsoleTable(int *tableToShow, int size);

#endif //SORT_MANAGEINTTABLE_H
