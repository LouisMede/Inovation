#include "manageIntTable.h"
#include "BubbleSort.h"

#define TABLE_SIZE 20

int main() {
    int intTableToSort[TABLE_SIZE];
    printf("\nTableau aléatoire : ");
    fillTableWithRandomInt(intTableToSort, TABLE_SIZE);
    showConsoleTable(intTableToSort, TABLE_SIZE);
    printf("\nTableau trié : ");
    bubbleSort(intTableToSort,TABLE_SIZE);
    showConsoleTable(intTableToSort, TABLE_SIZE);
    printf("Wesh poto");
    return 0;
}
